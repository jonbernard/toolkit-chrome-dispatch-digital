clearheader();

$(document).ready(function() {
						   
	updatestyles("Trending Mosaic","630px");

	disablesections();

	sitename("mosaic");

	sitepopup("mosaic","header");

	updatemeta();
	
	sitepopupfn(220);
	
});