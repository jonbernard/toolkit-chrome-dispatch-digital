setdefaultsite();

clearheader();

$(document).ready(function() {

	updatestyles("Trending Now","560px");

	sitename("lb");

	sitepopup("lb","header");

	updatemeta();
	
	sitepopupfn(240);

});