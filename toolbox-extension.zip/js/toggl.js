$(document).ready(function() {
						   
	$("#weekly-table thead .text-left").html("");
	$("#weekly-toggle").trigger('click');
	$(".report-print-header img").attr("src", "http://blog.toggl.com/wp-content/themes/togglver2/images/logo.png");

});