/* *** GET LOCALSTORAGE ***

This code gets the localstorage variables and allows the popup-js.js script to access the information.

*/
